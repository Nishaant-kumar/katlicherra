export const reviewsCard = [
  {
    id: 1,
    borderColor: "#FFB40080",
  },
];
