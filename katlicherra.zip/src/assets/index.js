import school_logo from "./school-logo.png";
import banner_bg from "./banner_bg.png";
import intro_img from "./intro_img.png";
import card_img from "./card_img.png";
import certificate1 from "./certificate1.png";
import certificate2 from "./certificate2.png";
import certificate3 from "./certificate3.png";
import open_comma from "./open_comma.png";
import close_comma from "./close_comma.png";
import WhatsApp from "./WhatsApp.png";
import geeta from "./geeta.png";
import geetam from "./geetam.png";
import kamlesh from "./kamlesh.png";

export {
  school_logo,
  banner_bg,
  intro_img,
  card_img,
  certificate1,
  certificate2,
  certificate3,
  open_comma,
  close_comma,
  WhatsApp,
  geeta,
  geetam,
  kamlesh,
};
