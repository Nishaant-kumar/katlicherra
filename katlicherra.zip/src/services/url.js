// get request url
export const getAllNoticeUrl = "/notices";
export const getAllEventsUrl = "/events";
