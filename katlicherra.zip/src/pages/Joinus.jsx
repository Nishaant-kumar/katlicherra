import React from "react";
import JoinuseSection from "../components/JoinusSection/JoinusSection";
const JoinUs = () => {
  return <JoinuseSection />;
};

export default JoinUs;
