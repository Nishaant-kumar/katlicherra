import React from "react";
import AcademicsSection from "../components/AcademicsSection";

const Academic = () => {
  return <AcademicsSection />;
};

export default Academic;
