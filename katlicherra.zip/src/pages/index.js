import Home from "./Home";
import JoinUs from "./Joinus";

export { Home, JoinUs };
